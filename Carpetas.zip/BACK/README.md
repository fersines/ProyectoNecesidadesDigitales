# Instrucciones

Crear un fichero .env con los contenidos de .env.example completados.
