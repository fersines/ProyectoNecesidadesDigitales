const listEntries = require("./listServicios");
const newUser = require("./newUser");
const getServicios = require("./getServicios");

module.exports = {
  listEntries,
  newUser,
  getServicios,
};
